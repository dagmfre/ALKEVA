/* @ds-bundle: {"format":4,"namespace":"ALKEVADesignSystem_d4c89d","components":[],"sourceHashes":{},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ALKEVADesignSystem_d4c89d = window.ALKEVADesignSystem_d4c89d || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

})();
